import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class Parser2014302580251 {
	public static void main(String[] args) throws IOException{
		
		File file=new File("Output.txt");
		file.createNewFile();
		FileOutputStream fileOutputStream=new FileOutputStream(file);
		PrintStream printStream=new PrintStream(fileOutputStream);
		System.setOut(printStream);
		
		Document doc = Jsoup.connect("http://www.bio.whu.edu.cn/News_reads.asp?cid=174&id=1501").get();
		Element content=doc.getElementById("headlines");
		String text =content.text();
		
		System.out.println("����:"+getName(doc));
		getIntroduction(doc);
		System.out.println("E-mail:"+getEmail(text));
		System.out.println("��ϵ�绰:"+getNumber(text));
		
	}
	
	
	public static String getName(Document d){
		Elements name=d.select("b");
		String strName=name.text();
		return strName;
	}
	
	public static void getIntroduction(Document d){
		Elements elements=d.getElementsByClass("zt2");
		for(int i=1;i<=6;i++){
			
			String elementText=elements.remove(1).text();
			System.out.println(elementText);
		}
	}
	
	public static String getEmail(String str){
		Pattern p=Pattern.compile("[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+");
		Matcher m=p.matcher(str);
		while(m.find()){
		return m.group();
		}
		return "";
	}
	
	public static String getNumber(String str){
		Pattern p=Pattern.compile("027-[0-9]{8}");
		Matcher m=p.matcher(str);
		while(m.find()){
		return m.group();
		}
		return "";
	}
}
	
